TBM INVOICE AND QUOTATION ANDROID APP SOURCE

This is the Android Studio project for the AL TEQANIA invoice/quotation app.

Included:
- Invoice and quotation generator
- Automatic numbering
- VAT and discount calculation
- Save/open/delete documents on the phone
- Remembered service descriptions
- Print to PDF using Android print service
- WhatsApp share
- Backup and restore JSON file

HOW TO BUILD THE APK
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Extract this ZIP.
3. In Android Studio choose Open and select the TeqaniaInvoice folder.
4. Wait for Gradle sync to finish (internet is required the first time).
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The APK will be in app/build/outputs/apk/debug/app-debug.apk.

Package: com.alteqania.invoice
App name: TBM Invoice
Minimum Android: 6.0

NOTE: This ZIP is Android source project, not a compiled APK. Compiling requires Android SDK/Gradle, which is not installed in this workspace.
